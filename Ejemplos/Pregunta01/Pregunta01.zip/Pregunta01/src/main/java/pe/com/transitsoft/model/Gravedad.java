package pe.com.transitsoft.model;

/**
 *
 * @author eric
 */
public enum Gravedad {
    LEVE, 
    GRAVE, 
    MUY_GRAVE
}
