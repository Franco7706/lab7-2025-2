/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.com.transitsoft.model;

/**
 *
 * @author Usuario
 */
public class Vehiculo {
    
    private int vehiculoId;
    private String placa;
    private String marca;
    private String modelo;
    private int anho;
    /**
     * @return the vehiculo_id
     */
    public int getVehiculoId() {
        return vehiculoId;
    }

    /**
     * @param vehiculo_id the vehiculo_id to set
     */
    public void setVehiculoId(int vehiculo_id) {
        this.vehiculoId = vehiculo_id;
    }

    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the anho
     */
    public int getAnho() {
        return anho;
    }

    /**
     * @param anho the anho to set
     */
    public void setAnho(int anho) {
        this.anho = anho;
    }
    
}
